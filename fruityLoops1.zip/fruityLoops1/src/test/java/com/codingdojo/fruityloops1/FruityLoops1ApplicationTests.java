package com.codingdojo.fruityloops1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruityLoops1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
